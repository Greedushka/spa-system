import React from 'react';
import Aside from "../../components/aside/aside";

const Settings = () => {
    return (
        <div className='section'>
            <Aside />
            <div className="wrapper">
                <div className="main-title">Настройки</div>
                <div className="main">123</div>
            </div>
        </div>
    );
};

export default Settings;